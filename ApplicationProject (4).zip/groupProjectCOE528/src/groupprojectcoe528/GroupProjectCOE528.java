package groupprojectcoe528;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import javafx.scene.paint.Color;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
//import GroupProject.OwnerStart;

/**
 *
 * @author dhruvi
 */
public class GroupProjectCOE528 extends Application 
{

    Button login = new Button("Login");
    
    TextField usernameField = new TextField();
    TextField passwordField = new TextField();
    Label incorrectPassword = new Label("");
    Text text = new Text("");
    String password;
    String username;
    String points;
    String username2;
    String points2;
    @Override
    public void start(Stage primaryStage) 
    {
       
        primaryStage.setTitle("Bookstore App"); 
        Scene scene = new Scene(loginScreen(), 525, 600);
        primaryStage.setScene(scene); 
        primaryStage.show();   
        customerStartScreen start2 = new customerStartScreen();
        ownerStartScreen start = new ownerStartScreen();
         File inputFile = new File("customers.txt");
         File credentials = new File("credentials.txt");
        login.setOnAction(new EventHandler<ActionEvent>()
        { 
            @Override
            public void handle(ActionEvent e) {
                if (!(usernameField.getText().equals("admin")) || (!(passwordField.getText().equals("admin"))))
                        {
                            text.setText("Incorrect Username or Password");
                        }
                if(usernameField.getText().equals("admin") && (passwordField.getText().equals("admin"))){
                            start.start(primaryStage);
                } 
                else{
                    try{
                    FileReader in = new FileReader("customers.txt");
                    Scanner scan = new Scanner(in);
                    while(scan.hasNextLine()){
                    String[] read = scan.nextLine().split(",");
                   for(int i=0; i<=read.length-1;i++){
                       if(i%2==1){
                           password = read[i];
                           
                       }
                       else if((2*i)==0){
                           username = read[i];
                          
                       }
                       else if((2*i) == 4){
                           points = read[i];
                           
                       }
                       
                   }
                       if(usernameField.getText().equals(username) && passwordField.getText().equals(password) ){
                           try (BufferedReader reader = new BufferedReader(new FileReader(inputFile))) {
                                BufferedWriter writer = new BufferedWriter(new FileWriter(credentials));
                                 String name = username;
                                 String password2=password;
                                 String points2 = points;
                                 String name4;
                                name4 = name + "," + password2+","+points2;
                               // System.out.println(name4);
                                writer.write(name4 + System.getProperty("line.separator"));
                                writer.close();
                                reader.close();
                      
                        } catch(IOException s){
                        System.out.println("An error occurred.");
                        s.printStackTrace();
                         }
                           start2.start(primaryStage);
                       }
                    }
                    in.close();
                    }catch(IOException s){
                        System.out.println("An error occurred.");
                        s.printStackTrace();
                    }

                 }   
            }
        });
        
    }

    public GridPane loginScreen()
    {
        GridPane loginGrid = new GridPane();
        loginGrid.setPadding(new Insets(11, 12, 13, 14)); //(bottom, left, top, right)
        loginGrid.setHgap(5);
        loginGrid.setVgap(5);
       // loginGrid.setAlignment(Pos.CENTER);
        Label welcomeLabel = new Label("Welcome to the BookStore App");
        welcomeLabel.setFont(Font.font("Times New Roman", FontWeight.NORMAL, 20));
        loginGrid.add(welcomeLabel, 0, 0, 2, 1);
        login.setFont(Font.font("Times New Roman", FontWeight.NORMAL, 15));
        loginGrid.add(login, 1, 4);    
        
        Label usernameLabel = new Label("Username:\t");
        usernameLabel.setFont(Font.font("Times New Roman", FontWeight.NORMAL, 15));
        Label passwordLabel = new Label("Password:\t");
        passwordLabel.setFont(Font.font("Times New Roman", FontWeight.NORMAL, 15));
        loginGrid.add(usernameLabel, 0, 1);
        loginGrid.add(usernameField, 1, 1);
        loginGrid.add(passwordLabel, 0, 2);
        loginGrid.add(passwordField, 1, 2);
        usernameField.setPromptText("Enter Username");
        passwordField.setPromptText("Enter Password");
        loginGrid.add(text, 1, 3);
        text.setFont(Font.font("Times New Roman", FontWeight.NORMAL, 13));
        text.setFill(Color.RED);//rgb(21, 117, 84));
        return loginGrid;
    }
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        launch(args);
    }
}
