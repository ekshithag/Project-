/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package groupprojectcoe528;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

/**
 *
 * @author dhruvi
 */
public class ownerStartScreen extends Application {
   
    Button booksButton = new Button("      Books     ");
    Button customersButton = new Button("  Customers  ");
    Button logout = new Button("     Logout     ");
    public Stage stage2;
    
    
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Bookstore App"); 
        Scene scene = new Scene(startScreen(), 450, 600);
        primaryStage.setScene(scene); 
        stage2 = primaryStage;
        primaryStage.show(); 
        ownerBooksScreen startToBooks = new ownerBooksScreen();
        ownerCustomersScreen startToCustomers = new ownerCustomersScreen();
        GroupProjectCOE528 logoutToLogin = new GroupProjectCOE528();
        
        booksButton.setOnAction(new EventHandler<ActionEvent>()
        { 
            @Override
            public void handle(ActionEvent e) {
               startToBooks.start(primaryStage);
                
            }
        });
        
        customersButton.setOnAction(new EventHandler<ActionEvent>()
        { 
            @Override
            public void handle(ActionEvent e) {
               
               startToCustomers.start(primaryStage);
                
            }
        });
         
        logout.setOnAction(new EventHandler<ActionEvent>()
        { 
            @Override
            public void handle(ActionEvent e) {
               
               logoutToLogin.start(primaryStage);
                
            }
        });
        
    }
    
    public GridPane startScreen()
    {
        GridPane startGrid = new GridPane();
        startGrid.setPadding(new Insets(10, 12, 13, 14)); 
        startGrid.setHgap(20);
        startGrid.setVgap(12);
        startGrid.add(booksButton, 1, 4);   
        startGrid.add(customersButton, 1, 6);   
        startGrid.add(logout, 1, 8);   
        return startGrid;
    }

    public Stage getStage(){
        return stage2;
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}
