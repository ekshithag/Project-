/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package groupprojectcoe528;

//import com.sun.xml.internal.fastinfoset.alphabet.BuiltInRestrictedAlphabets.table;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.CheckBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Callback;
 
public class customerStartScreen extends Application {
    String name;
    String price;
    String username,password;
    String points,pointsTotal;
    String status;
    double pointsconvert;
    double totalpoints;
    double price3;
    String status1,status2,personname;
    String old2;
    private TableView<Person> table = new TableView<Person>();
    private final ObservableList<Person> information =
            FXCollections.observableArrayList();
    public ArrayList<String> prices = new ArrayList<>();
    //formats text fields and add button in horizontal row or verticle column 
    final HBox horizontalbox = new HBox();
    public static void main(String[] args) {
        launch(args);
    }
    public void tableSelect(){
            table.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    }
    @Override
    public void start(Stage stage) {
        Scene scene = new Scene(new Group());
        stage.setTitle("Bookstore App");
        stage.setWidth(450);
        stage.setHeight(600);
        try{
                    FileReader in = new FileReader("credentials.txt");
                    Scanner scan = new Scanner(in);
                    while(scan.hasNextLine()){
                    String[] read = scan.nextLine().split(",");
                    for(int i=0; i<=read.length-1;i++){
                       if(2*i == 0){
                           username = read[i]; 
                       }
                       else if(2*i == 4){
                           points = read[i];  
                           pointsconvert= Double.parseDouble(points);
                       }
                       else if(i%2 == 1){
                           password = read[i];
                       }
                       if(pointsconvert >= 1000){
                               status = "Gold";
                           }
                       else{
                               status = "Silver";
                       }
                               old2 = username+","+password+","+points;          
                   }
                      
                    }
                    in.close();
                    }catch(IOException s){
                        System.out.println("An error occurred.");
                        s.printStackTrace();
                    }  
         final Label label = new Label("Welcome "+username +". \nYou have " + points +" points. \nYour status is " + status+".");
         label.setFont(new Font("Times New Roman", 18));
       
        
//2D array (list)
        Callback<TableColumn, TableCell> cellFactory =
             new Callback<TableColumn, TableCell>() {
                 public TableCell call(TableColumn p) {
                    return new EditingCell();
                 }
             };
 
        //username title
        TableColumn userNameCol = new TableColumn("Book Name");
        userNameCol.setMinWidth(150);
        userNameCol.setCellValueFactory(
            new PropertyValueFactory<Person, String>("name"));
        userNameCol.setCellFactory(cellFactory);
 
     TableColumn passWordCol = new TableColumn("Book Price");
        passWordCol.setMinWidth(150);
        passWordCol.setCellValueFactory(
        new PropertyValueFactory<Person, String>("password"));
        passWordCol.setCellFactory(cellFactory);
        
        
        TableColumn<Person,Boolean> c2 = new TableColumn<Person,Boolean>("Select");
        c2.setCellValueFactory(new PropertyValueFactory<Person,Boolean>("check"));
        c2.setMinWidth(100);
        c2.setCellFactory(column -> new CheckBoxTableCell()); 
       // table.getColumns().add(c2);
        tableSelect();
        table.setItems(information);
        table.getColumns().addAll(userNameCol, passWordCol, c2);
         ObservableList<Person> list = table.getSelectionModel().getSelectedItems();
         table.getItems().removeAll(list);
         
         table.getItems().removeAll(list);
        customerCostScreen start2 = new customerCostScreen();
        final Button redeemBuyButton = new Button("Redeem Points & Buy");// acts as the delete button
        final Button buyButton = new Button("Buy");
        File inputFile = new File("books.txt");
         File checkoutFile = new File("customerCheckout.txt");
         File checkoutFile2 = new File("credentials2.txt");
         File tempFile2 = new File("customers.txt");
          File replace = new File("replace2.txt");
        buyButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                    try (BufferedReader reader = new BufferedReader(new FileReader(inputFile))) {
                        BufferedWriter writer = new BufferedWriter(new FileWriter(checkoutFile));
                        BufferedWriter writer2 = new BufferedWriter(new FileWriter(checkoutFile2));
                         String price2;
                         String name3;
                         String name4;
                         for(int i =0;i<list.size();i++){
                             price2 = list.get(i).getPassword();
                             name3 = list.get(i).getName();
                             name4 = name3 + "," + price2;
                             price3 = Double.parseDouble(price2);
                             totalpoints = pointsconvert+price3*10;
                             pointsTotal = Double.toString(totalpoints);
                             personname = username+","+password+","+pointsTotal;
                             writer2.write(personname + System.getProperty("line.separator"));
                             writer.write(name4 + System.getProperty("line.separator"));
                         }              
                        writer.close();
                        reader.close();
                        writer2.close();
                    } catch(IOException s){
                    System.out.println("An error occurred.");
                    s.printStackTrace();
                     }
                                    
               try (BufferedReader reader = new BufferedReader(new FileReader(tempFile2))) {
                        BufferedWriter writer = new BufferedWriter(new FileWriter(replace));
                        String currentLine;
                        
                        while((currentLine = reader.readLine())!=null ){ 
                            if(currentLine.equals(old2)){
                                currentLine = username+","+password+","+pointsTotal;
                            }
                            
                            writer.write(currentLine + System.getProperty("line.separator"));
                        }
                        writer.close();
                        reader.close();
                        boolean delete = tempFile2.delete();
                        boolean b = replace.renameTo(tempFile2);
                    } catch(IOException s){
                    System.out.println("An error occurred.");
                    s.printStackTrace();
                    }
               
                 start2.start(stage);
            }
        });
       // tableSelect();
       File tempFile = new File("temps.txt");
       File file2 = new File("books.txt");
         File checkoutFile4 = new File("credentials2.txt");
         redeemBuyButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                
                 try (BufferedReader reader = new BufferedReader(new FileReader(inputFile))) {
                        BufferedWriter writer2 = new BufferedWriter(new FileWriter(checkoutFile4));
                         String price2;
                         String name3;
                         String name4;
                         for(int i =0;i<list.size();i++){
                             price2 = list.get(i).getPassword();
                             name3 = list.get(i).getName();
                             name4 = name3 + "," + price2;
                             price3 = Double.parseDouble(price2);
                            
                             totalpoints = pointsconvert-price3*10;
                             pointsTotal = Double.toString(totalpoints);
                             personname = username+","+password+","+pointsTotal;
                             System.out.println("Password"+password);
                             writer2.write(personname + System.getProperty("line.separator"));
                               
                         }
                                                 
                        writer2.close();
                        reader.close();
                    } catch(IOException s){
                    System.out.println("An error occurred.");
                    s.printStackTrace();
                     }
                 try (BufferedReader reader = new BufferedReader(new FileReader(tempFile2))) {
                        BufferedWriter writer = new BufferedWriter(new FileWriter(replace));
                        String currentLine;
                        
                        while((currentLine = reader.readLine())!=null ){ 
                            if(currentLine.equals(old2)){
                                currentLine = username+","+password+","+pointsTotal;
                            }
                            
                            writer.write(currentLine + System.getProperty("line.separator"));
                        }
                        writer.close();
                        reader.close();
                        boolean delete = tempFile2.delete();
                        boolean b = replace.renameTo(tempFile2);
                    } catch(IOException s){
                    System.out.println("An error occurred.");
                    s.printStackTrace();
                    }
                     start2.start(stage);
                 
            }
        });
        
        final HBox horizontalbox2 = new HBox();
         try{
            FileReader in = new FileReader("books.txt");
            Scanner scan = new Scanner(in);
            while(scan.hasNextLine()){
                String[] read = scan.nextLine().split(",");
                   for(int i=0; i<=read.length-1;i++){
                       if(i%2==1){
                           price = read[i];
                           
                       }
                       else if((2*i)==0){
                           name = read[i];
                          
                       }
                       
                   }
                   information.add(new Person(
                        name,
                        price));
                  
                
            }
            in.close();
          }catch(IOException s){
                System.out.println("An error occurred.");
                s.printStackTrace();
            }
         
        horizontalbox2.getChildren().addAll(buyButton, redeemBuyButton);
        horizontalbox2.setSpacing(59);
         final VBox vbox2 = new VBox();
        vbox2.getChildren().addAll(horizontalbox2);
        vbox2.setPadding(new Insets(500, 0, 0, 16));
        //(,,,left)
        ((Group) scene.getRoot()).getChildren().addAll(vbox2);
 
        stage.setScene(scene);
        stage.show();
        
        horizontalbox.getChildren().addAll(/*addName, addPassword, addPoints,*/);
       
        //set space between textfield and buttons
        horizontalbox.setSpacing(18);
 
        final VBox vbox = new VBox();
        
        //spacing between textfield/button and the table
        vbox.setSpacing(18);
        
        //(left,0,0,down)
        vbox.setPadding(new Insets(10, 0, 0, 15));
        vbox.getChildren().addAll(label, table, horizontalbox);
 
        ((Group) scene.getRoot()).getChildren().addAll(vbox);
 
        stage.setScene(scene);
        stage.show();
    }
  
   
    //nested class
     public static class Person {
 
        private final SimpleStringProperty name;
        private final SimpleStringProperty price;
       
        private Person(String bname, String bprice){// boolean Checked) {
            this.name = new SimpleStringProperty(bname);
            this.price = new SimpleStringProperty(bprice);
            
        }
 
        public String getName() {
            return name.get();
        }
 
        public void setName(String bname) {
            name.set(bname);
        }
 
        public String getPassword() {
            return price.get();
        }
 
        public void setPassword(String bprice) {
            price.set(bprice);
        }
      
    }
 
    class EditingCell extends TableCell<Person, String> {
 
        private TextField textField;
 
        @Override
        public void updateItem(String item, boolean empty) {
            super.updateItem(item, empty);
 
            if (empty) {
                setText(null);
                setGraphic(null);
            } else {
                if (isEditing()) {
                    if (textField != null) {
                        textField.setText(getString());
                    }
                    setText(null);
                    setGraphic(textField);
                } else {
                    setText(getString());
                    setGraphic(null);
                }
            }
        }
 
        private String getString() {
            return getItem() == null ? "" : getItem().toString();
        }
  
    }
        
}
