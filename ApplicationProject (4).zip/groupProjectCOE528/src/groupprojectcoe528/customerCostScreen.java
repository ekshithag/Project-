package groupprojectcoe528;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

/**
 *
 * @author dhruvi
 */
public class customerCostScreen extends Application {
   
    Button logout = new Button("     Logout     ");
    public Stage stage2;
    final HBox horizontalbox = new HBox();
    String name;
    String price;
    double totalpoints,totalpoints3;
    double pointSum;
    GridPane costScreen = new GridPane();
    double priceconvert;
    String status,status2;
    String password;
    String points,totalpoints2;
    String compname, comppass, comppoints; 
    String old,combined,test;
    boolean check = false;
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Bookstore App"); 
        Scene scene = new Scene(customerCostScreens(), 450, 600);
        primaryStage.setScene(scene); 
        stage2 = primaryStage;
        primaryStage.show(); 
        GroupProjectCOE528 logoutToLogin = new GroupProjectCOE528();
       try{
                    FileReader in = new FileReader("credentials.txt");
                    Scanner scan = new Scanner(in);
                    while(scan.hasNextLine()){
                    String[] read = scan.nextLine().split(",");
                    for(int i=0; i<=read.length-1;i++){
                       if(2*i == 0){
                           compname = read[i]; 
                          // System.out.println(compname);
                       }
                       else if(i%2 == 1){
                          comppass = read[i];
                        //  System.out.println(comppass);
                       }
                       else if(2*i == 4){
                         comppoints = read[i];
                        //  System.out.println(comppoints);  
                       } 
                      old = compname+","+comppass+","+comppoints;
                                    
                   }
                      
                    }
                    in.close();
                    }catch(IOException s){
                        System.out.println("An error occurred.");
                        s.printStackTrace();
                    }    
       try{
                    FileReader in = new FileReader("customerCheckout.txt");
                    Scanner scan = new Scanner(in);
                    
                    while(scan.hasNextLine()){
                    String[] read = scan.nextLine().split(",");
                    for(int i=0; i<=read.length-1;i++){
                       if(i%2==1){
                        
                           price = read[i];
                           priceconvert= priceconvert+Double.parseDouble(price);
                           //System.out.println(priceconvert);
                       }
                                      
                   }
                      
                    }
                    in.close();
                    }catch(IOException s){
                        System.out.println("An error occurred.");
                        s.printStackTrace();
                    }    
                 try{
                    FileReader in = new FileReader("credentials2.txt");
                    Scanner scan = new Scanner(in);
                    
                    while(scan.hasNextLine()){
                    String[] read = scan.nextLine().split(",");
                    for(int i=0; i<=read.length-1;i++){
                       if(2*i==4){
                           totalpoints2 = read[i];
                           totalpoints3 = Double.parseDouble(totalpoints2);
                          // System.out.println(totalpoints3);
                           
                           if(totalpoints3 >= 1000){
                               status = "Gold";
                              
                           }
                           else if(totalpoints3>=0&&totalpoints3<1000){
                               status = "Silver";
                              
                           }
                                                   
                       }
                                      
                   }
                      
                    }
                    in.close();
                    }catch(IOException s){
                        System.out.println("An error occurred.");
                        s.printStackTrace();
                    }
                        Label cost = new Label("Total Cost: " + priceconvert);
                        cost.setFont(new Font("Times New Roman", 20));
                        costScreen.add(cost, 1, 4);   
                        Label pointsStatus = new Label("Points: "+ totalpoints3 +", Status: "+status);
                        pointsStatus.setFont(new Font("Times New Roman", 20));
                        costScreen.add(pointsStatus, 1, 5); 
                          
        logout.setOnAction(new EventHandler<ActionEvent>()
        { 
            @Override
            public void handle(ActionEvent e) {
               
               logoutToLogin.start(primaryStage);
                
            }
        });
        horizontalbox.getChildren().addAll(/*addName, addPassword, addPoints,*/);
       
      
    }
    
   
    public GridPane customerCostScreens()
    {
        costScreen.setPadding(new Insets(11, 0, 0, 14)); //(bottom, left, top, right)
        costScreen.setHgap(5);
        costScreen.setVgap(5); 
        costScreen.add(logout, 1, 8);  
        return costScreen;
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}
