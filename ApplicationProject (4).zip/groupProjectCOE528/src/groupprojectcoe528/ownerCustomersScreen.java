/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package groupprojectcoe528;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Callback;

 
public class ownerCustomersScreen extends Application {
    String username;
    String password;
    String points;
    final Button deleteButton = new Button("Delete");
    final Button backButton = new Button("Back");
         
    private TableView<Person> table = new TableView<Person>();
     private final ObservableList<Person> information =
            FXCollections.observableArrayList();
   
    //formats text fields and add button in horizontal row or verticle column 
    final HBox horizontalbox = new HBox();
 
    public static void main(String[] args) {
        launch(args);
    }
 
    @Override
    public void start(Stage stage) {
        Scene scene = new Scene(new Group());
        stage.setTitle("BookStore App");
        stage.setWidth(450);
        stage.setHeight(600);
        ownerStartScreen customersToStart = new ownerStartScreen();
        
        final Label label = new Label("Owner Customer Screen");
        label.setFont(new Font("Times New Roman", 20));
        
        backButton.setOnAction(new EventHandler<ActionEvent>()
        { 
            @Override
            public void handle(ActionEvent e) {
               customersToStart.start(stage);
            }
        });
        try{
           FileReader in = new FileReader("customers.txt");
            Scanner scan = new Scanner(in);
            while(scan.hasNextLine()){
                String[] read = scan.nextLine().split(",");
                   for(int i=0; i<=read.length-1;i++){
                       if(i%2==1){
                           password = read[i];
                           
                       }
                       else if((2*i)==0){
                           username = read[i];
                          
                       }
                       else if(2*i == 4){
                           points = read[i];
                       }
                       
                   }
                   information.add(new Person(
                        username,
                        password,
                        points));

                
            }
            in.close();
          }catch(IOException s){
                System.out.println("An error occurred.");
                s.printStackTrace();
            }
//2D array (list)
        Callback<TableColumn, TableCell> cellFactory =
             new Callback<TableColumn, TableCell>() {
                 public TableCell call(TableColumn p) {
                    return new EditingCell();
                 }
             };
 
        //username title
        TableColumn userNameCol = new TableColumn("Username");
        userNameCol.setMinWidth(100);
        userNameCol.setCellValueFactory(
            new PropertyValueFactory<Person, String>("name"));
        userNameCol.setCellFactory(cellFactory);
 
     TableColumn passWordCol = new TableColumn("Password");
        passWordCol.setMinWidth(100);
        passWordCol.setCellValueFactory(
        new PropertyValueFactory<Person, String>("password"));
        passWordCol.setCellFactory(cellFactory);
        
        TableColumn pointsCol = new TableColumn("Points");
        pointsCol.setMinWidth(200);
        pointsCol.setCellValueFactory(
            new PropertyValueFactory<Person, String>("points"));
        pointsCol.setCellFactory(cellFactory);
        
 
        table.setItems(information);
        table.getColumns().addAll(userNameCol, passWordCol, pointsCol);
        
        final TextField addName = new TextField();
        addName.setPromptText("Username");
        addName.setMaxWidth(userNameCol.getPrefWidth());
        final TextField addPassword = new TextField();
        addPassword.setMaxWidth(passWordCol.getPrefWidth());
        addPassword.setPromptText("Password");
        final TextField addPoints = new TextField();
        addPoints.setMaxWidth(pointsCol.getPrefWidth());
        addPoints.setPromptText("Points");
        final Button addButton = new Button("Add");
        addButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                information.add(new Person(
                        addName.getText(),
                        addPassword.getText(),
                        addPoints.getText()));
                    
                   Person customer = new Person(addName.getText(), addPassword.getText(), addPoints.getText());

                    
                    
                try (BufferedWriter bw = new BufferedWriter(new FileWriter("customers.txt", true))) {
                     bw.write(customer.getName()+ ",");
                     bw.write(customer.getPassword()+ ",");
                     bw.write(customer.getPoints());
                     bw.newLine();
                } catch (IOException s) {
                      s.printStackTrace();
                }
                addName.clear();
                addPassword.clear();
                addPoints.clear();
             }
        });
        
        final HBox horizontalbox2 = new HBox();
        File inputFile = new File("customers.txt");
        File tempFile = new File("temporary.txt");
         deleteButton.setOnAction(new EventHandler<ActionEvent>(){
                @Override
                public void handle(ActionEvent e) {
                Person selectedItem = table.getSelectionModel().getSelectedItem();
                 table.getItems().remove(selectedItem);
                 try (BufferedReader reader = new BufferedReader(new FileReader(inputFile))) {
                        BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));
                         String name = selectedItem.getName();
                         String password = selectedItem.getPassword();
                         String points =  selectedItem.getPoints();
                         String name2 = name + "," + password+","+points;
                        String currentLine;
                        
                        while((currentLine = reader.readLine())!=null ){ 
                            if(currentLine.equals(name2)){
                                currentLine = "";
                            }
                           if(!currentLine.isEmpty()){
                                writer.write(currentLine + System.getProperty("line.separator"));
                           }
                        }
                        writer.close();
                        reader.close();
                        boolean delete = inputFile.delete();
                        boolean b = tempFile.renameTo(inputFile);
                    } catch(IOException s){
                    System.out.println("An error occurred.");
                    s.printStackTrace();
                     }
          }});
        
        horizontalbox2.getChildren().addAll(backButton, deleteButton);
        horizontalbox2.setSpacing(59);
         final VBox vbox2 = new VBox();
        vbox2.getChildren().addAll(horizontalbox2);
        vbox2.setPadding(new Insets(500, 0, 0, 16));
        //(,,,left)
        ((Group) scene.getRoot()).getChildren().addAll(vbox2);
 
        stage.setScene(scene);
        stage.show();
        
        horizontalbox.getChildren().addAll(addName, addPassword, addPoints, addButton);
       
        //set space between textfield and buttons
        horizontalbox.setSpacing(18);
 
        final VBox vbox = new VBox();
        
        //spacing between textfield/button and the table
        vbox.setSpacing(18);
        
        //(left,0,0,down)
        vbox.setPadding(new Insets(10, 0, 0, 15));
        vbox.getChildren().addAll(label, table, horizontalbox);
 
        ((Group) scene.getRoot()).getChildren().addAll(vbox);
 
        stage.setScene(scene);
        stage.show();
    }
  
 
    //nested class
     public static class Person {
 
        private final SimpleStringProperty Name;
        private final SimpleStringProperty passWord;
        private final SimpleStringProperty points;
 
        private Person(String fName, String lName, String points) {
            this.Name = new SimpleStringProperty(fName);
            this.passWord = new SimpleStringProperty(lName);
            this.points = new SimpleStringProperty(points);
        }
 
        public String getName() {
            return Name.get();
        }
 
        public void setName(String fName) {
            Name.set(fName);
        }
 
        public String getPassword() {
            return passWord.get();
        }
 
        public void setPassword(String fName) {
            passWord.set(fName);
        }
 
        public String getPoints() {
            return points.get();
        }
 
        public void setPoints(String fName) {
            points.set(fName);
        }
    }
 
    class EditingCell extends TableCell<Person, String> {
 
        private TextField textField;
 
        @Override
        public void updateItem(String item, boolean empty) {
            super.updateItem(item, empty);
 
            if (empty) {
                setText(null);
                setGraphic(null);
            } else {
                if (isEditing()) {
                    if (textField != null) {
                        textField.setText(getString());
                    }
                    setText(null);
                    setGraphic(textField);
                } else {
                    setText(getString());
                    setGraphic(null);
                }
            }
        }
 
        private String getString() {
            return getItem() == null ? "" : getItem().toString();
        }
  
    }
        
}
