/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package groupprojectcoe528;

import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.util.Callback;
import javafx.stage.Stage;
import java.io.*;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;
 
public class ownerBooksScreen extends Application {
    String name;
    String price;
    final Button deleteButton = new Button("Delete");
    final Button backButton = new Button("Back");
    final Button addButton = new Button("Add");
    final TextField addBookPrice = new TextField();
    final static TextField addName = new TextField();
    //Person books = new Person(addName.getText(), addBookPrice.getText());
    private TableView<Person> table = new TableView<Person>();
    private final ObservableList<Person> information =
            FXCollections.observableArrayList();
     
    final HBox horizontalbox = new HBox();
    
    public static void main(String[] args) {
        launch(args);
        
      
    }
  

    @Override
    public void start(Stage stage) {
        ownerStartScreen booksToStart = new ownerStartScreen();
        Scene scene = new Scene(new Group());
        stage.setTitle("BookStore App");
        stage.setWidth(450);
        stage.setHeight(600);
 
        final Label label = new Label("Owner Book Screen");
        label.setFont(new Font("Times New Roman", 20));
       // addButton.setOnAction(e -> addName.setText(addName.getText()));
        backButton.setOnAction(new EventHandler<ActionEvent>()
        { 
            @Override
            public void handle(ActionEvent e) {
               booksToStart.start(stage);
            }
        });
        
//2D array (list)
        Callback<TableColumn, TableCell> cellFactory =
             new Callback<TableColumn, TableCell>() {
                 public TableCell call(TableColumn p) {
                    return new EditingCell();
                 }
             };
 
        //username title
        TableColumn bookNameCol = new TableColumn("Book Name");
        bookNameCol.setMinWidth(200);
        bookNameCol.setCellValueFactory(
        new PropertyValueFactory<Person, String>("bookName"));
        bookNameCol.setCellFactory(cellFactory);
 
        TableColumn bookPriceCol = new TableColumn("Book Price");
        bookPriceCol.setMinWidth(200);
        bookPriceCol.setCellValueFactory(
        new PropertyValueFactory<Person, String>("bookPrice"));
        bookPriceCol.setCellFactory(cellFactory);
 
        table.setItems(information);
        table.getColumns().addAll(bookNameCol, bookPriceCol);
 
       // final TextField addName = new TextField();
        addName.setPromptText("Book Name");
        addName.setMaxWidth(bookNameCol.getPrefWidth());
        
        addBookPrice.setMaxWidth(bookPriceCol.getPrefWidth());
        addBookPrice.setPromptText("Book Price");
               
        
        addButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent e) {
                information.add(new Person(
                        addName.getText(),
                        addBookPrice.getText()));                 
                    
                Person books = new Person(addName.getText(), addBookPrice.getText());
                try (BufferedWriter bw = new BufferedWriter(new FileWriter("books.txt", true))) {
                     bw.write(books.getBookName()+ ",");
                     bw.write(books.getBookPrice());
                     bw.newLine();
                } catch (IOException s) {
                      s.printStackTrace();
                }
                addName.clear();
                addBookPrice.clear();
                
                }
                
            
        });
      
            try{
            FileReader in = new FileReader("books.txt");
            Scanner scan = new Scanner(in);
            while(scan.hasNextLine()){
                String[] read = scan.nextLine().split(",");
                   for(int i=0; i<=read.length-1;i++){
                       if(i%2==1){
                           price = read[i];
                           
                       }
                       else if((2*i)==0){
                           name = read[i];
                       }
                       
                   }
                   information.add(new Person(
                        name,
                        price));                
            }
            in.close();
          }catch(IOException s){
                System.out.println("An error occurred.");
                s.printStackTrace();
            }
      //  }
       
        final HBox horizontalbox2 = new HBox();
        horizontalbox2.getChildren().addAll(backButton, deleteButton);
         File inputFile = new File("books.txt");
          File tempFile = new File("myTempFile.txt");
        deleteButton.setOnAction(new EventHandler<ActionEvent>(){
                @Override
                public void handle(ActionEvent e) {
                Person selectedItem = table.getSelectionModel().getSelectedItem();
                    try (BufferedReader reader = new BufferedReader(new FileReader(inputFile))) {
                        BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));
                         String price = selectedItem.getBookPrice();
                         String name = selectedItem.getBookName();
                         String name2 = name + "," + price;
                        String currentLine;
                        
                        while((currentLine = reader.readLine())!=null ){ 
                            if(currentLine.equals(name2)){
                                currentLine = "";
                            }
                           if(!currentLine.isEmpty()){
                                writer.write(currentLine + System.getProperty("line.separator"));
                           }
                        }
                        writer.close();
                        reader.close();
                        boolean delete = inputFile.delete();
                        boolean b = tempFile.renameTo(inputFile);
                    } catch(IOException s){
                    System.out.println("An error occurred.");
                    s.printStackTrace();
                     }
                
              
                table.getItems().remove(selectedItem);
                
          }});
       
        horizontalbox2.setSpacing(56);
         final VBox vbox2 = new VBox();
        vbox2.getChildren().addAll(horizontalbox2);
        vbox2.setPadding(new Insets(500, 0, 0, 16));//buttons
        //(,,,left)
        ((Group) scene.getRoot()).getChildren().addAll(vbox2);
 
        stage.setScene(scene);
        stage.show();
        
        horizontalbox.getChildren().addAll(addName, addBookPrice, addButton);
       
        //set space between textfield and buttons
        horizontalbox.setSpacing(18);
 
        final VBox vbox = new VBox();
        
        //spacing between textfield/button and the table
        vbox.setSpacing(18);
      
        vbox.setPadding(new Insets(10, 0, 0, 15));//table
        vbox.getChildren().addAll(label, table, horizontalbox);
 
        ((Group) scene.getRoot()).getChildren().addAll(vbox);
 
        stage.setScene(scene);
        stage.show();
    }
 
     public static class Person {    
        private final SimpleStringProperty bookName;
        private final SimpleStringProperty bookPrice;
 
        private Person(String bName, String bPrice){
            this.bookName = new SimpleStringProperty (bName);//new SimpleStringProperty(fName);
            this.bookPrice = new SimpleStringProperty(bPrice);
        }
 
        public String getBookName() {
            return bookName.get();
        }
 
        public void setBookName(String fName) {
           bookName.set(fName);
        }
 
        public String getBookPrice() {
            return bookPrice.get();
        }
 
        public void setBookPrice(String bPrice) {
            bookPrice.set(bPrice);
        }
    }
 
    class EditingCell extends TableCell<Person, String> {
 
        private TextField textField;
 
        //@Override
        public void updateItem(String item, boolean empty) {
            super.updateItem(item, empty);
 
            if (empty) {
                setText(null);
                setGraphic(null);
            } else {
                if (isEditing()) {
                    if (textField != null) {
                        textField.setText(getString());
                    }
                    setText(null);
                    setGraphic(textField);
                } else {
                    setText(getString());
                    setGraphic(null);
                }
            }
        }
 
        private String getString() {
            return getItem() == null ? "" : getItem().toString();
        }
  
    }
}
